#include <iostream>
#include "TicTacToe.h"

using namespace std;

void resetBoard() {
    char value = '1';

    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            board[i][j] = value++;
        }
    }
}

int main() {
    char playAgain;

    do {
        resetBoard();

        char currentPlayer = 'X';
        int choice;

        cout << "===== TIC TAC TOE GAME =====\n";

        while(true) {
            displayBoard();

            cout << "Player " << currentPlayer
                 << ", enter your choice (1-9): ";
            cin >> choice;

            if(!isValidMove(choice)) {
                cout << "Invalid move! Try again.\n";
                continue;
            }

            makeMove(choice, currentPlayer);

            if(checkWin(currentPlayer)) {
                displayBoard();
                cout << "Player " << currentPlayer
                     << " wins!\n";
                break;
            }

            if(isDraw()) {
                displayBoard();
                cout << "Game is a draw!\n";
                break;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }

        cout << "Do you want to play again? (y/n): ";
        cin >> playAgain;

    } while(playAgain == 'y' || playAgain == 'Y');

    cout << "Thank you for playing!\n";

    return 0;
}
