# Mini Game Project - Tic Tac Toe

## Description
This is a simple console-based Tic Tac Toe game developed in C++. The project demonstrates core programming concepts such as loops, arrays, conditional statements, functions, and game logic.

## Features
- Two-player Tic Tac Toe game
- Dynamic board display
- Win and draw detection
- Replay option
- Console-based interface

## Technologies Used
- C++
- Arrays
- Loops
- Functions
- Conditional Statements

## How to Run

### Compile
```bash
g++ main.cpp -o game
```

### Run
```bash
./game
```

## Project Structure
- `main.cpp` → Main game logic
- `TicTacToe.h` → Game functions and board handling

## Output
The game allows two players to play Tic Tac Toe interactively in the console.

## Author
Your Name
